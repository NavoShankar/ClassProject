package TurtleGraphics;

public class MainBridge {

	public static void main(String[] args) {
		FunctionBridge object = new FunctionBridge();
		int printProgram = 0;
		object.Output(printProgram);
		
			
		}
}
	
