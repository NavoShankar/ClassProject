package TurtleGraphics.gameobject;

import java.awt.event.MouseEvent;

import TurtleGraphics.Puzzle;
import TurtleGraphics.game.Game;
import TurtleGraphics.graphics.Renderer;
import TurtleGraphics.graphics.Sprite;
import TurtleGraphics.input.Mouse;

public class Rect {

	public double x, y, nx, ny, ox, oy;
	public int width, height;
	public Sprite sprite;
	
	public boolean moving = false;
	
	public Rect(double x, double y, Sprite sprite) {
		this.x = x;
		this.y = y;
		this.width = sprite.width;
		this.height = sprite.height;
		this.sprite = sprite;
	}
	
	private boolean checkIfValidMove() {
		nx = (int) (Math.round(x / 100) * 100);
		ny = (int) (Math.round(y / 100) * 100);
		int xDiff = (int) (Math.abs(nx - ox));
		int yDiff = (int) (Math.abs(ny - oy));
		if(nx < 0 || ny < 0 || nx >= Puzzle.WIDTH || ny >= Puzzle.HEIGHT || xDiff > 100 || yDiff > 100) return false;
		if(xDiff == 100 && yDiff == 100) return false;
		for(int i = 0; i < Game.rects.length; i++) {
			if(nx == Game.rects[i].x && ny == Game.rects[i].y) {
				return false;
			}
		}
		return true;
	}
	
	public void update() {
		if(Mouse.buttonDown(MouseEvent.BUTTON1)) {
			if(Mouse.getX() > x && Mouse.getX() < x + width && Mouse.getY() > y && Mouse.getY() < y + height) {
				moving = true;
				ox = x;
				oy = y;
			}
		}
		if(moving && Mouse.isDragging()) {
			int mx = Mouse.getX();
			int my = Mouse.getY();
			x = mx - width / 2;
			y = my - height / 2;
		}else if(moving && !Mouse.isDragging()) {
			if(checkIfValidMove()) {
				x = nx;
				y = ny;
			}else {
				x = ox;
				y = oy;
			}
			moving = false;
		}
	}
	
	public void render() {
		Renderer.renderSprite(sprite, (int) x, (int) y);
	}
}
