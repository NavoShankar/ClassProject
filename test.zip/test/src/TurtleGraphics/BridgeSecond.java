package TurtleGraphics;

import java.util.Random;

public class BridgeSecond {
	
	public void Output(int sizeOfbridge) {
		Random rand = new Random();
		
		int avg=0; int max=0; 
		int position = 0;

		for(int i=0;i<50;i++){
			
			position=0; int count1=0;
			
		
			while(position!=4 && position!=-4){
				
				int step= rand.nextInt((1) + 1) + 0;
				
				if(step==1){
					position++;
			}
				if(step==0){
					position--;
			}
				count1++;

		}
			avg=avg+count1;
			
			if(count1>max) {
				max=count1;
				
			}
			
			System.out.print("|");
			for(int count=1;count<position;count++) {
		    	 System.out.print("-");
		     }
		     
		     System.out.print("*");
		     
		     for(int count=position;count<=sizeOfbridge;count++)
		    	 for(count=0;count<=sizeOfbridge;count++)
		     
		     {
		    	 System.out.print("-");
		     }
		     System.out.println("|");
		     
						
		}
		double d=avg/50;
		System.out.println("Average of 50 trials is "+d+"\nMaximum steps taken in 50 trials is "+max);
	}
			
}

		     
		 
		     
		
		
	
		
	
	





