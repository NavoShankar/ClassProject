package TurtleGraphics;

import java.util.Random;

public class FunctionBridge {

		public void Output(int Length) {
		
			Random gen = new Random();
			int amtOftrials = 0, step=0, avg = 0, number = 0;
			Length = 5;
			while (Length<=21)
			{
			amtOftrials = 0;
			while (amtOftrials != 1)// I have it set to 1 so you can see the output on the console. But, you can just change the 1 to 50 if you want it to keep going to 50 trials each time.
			{
			int Limit=Length;
			int Position = Length/2+1;
			step=0;
			while(Position>=1&&Position<=Limit)
			{
			System.out.print("|");
			for(int count=1;count<Position;count++)
			{
			System.out.print("-");
			}
			System.out.print("*");
			for(int count=Position;count<Limit;count++)
			{
			System.out.print("-");
			}
			System.out.print("|");
			System.out.println("");
			number = gen.nextInt(2);
			if (number%2==0)
			{
			Position++;
			}
			else if (number%2!=0)
			{
			Position--;
			}
			step++;
			avg = avg + step;
			}
			amtOftrials++;
			step--;
			double oneLength=(double)step/50;
			System.out.println("You fell off of the bridge in "+step+" steps. The Length of the Bridge was "+Length);
			//the avg for the specfic length
			System.out.println("The Average Amount of Steps for the length "+Length+" was "+oneLength+" steps");
			}
			Length+=2;
			}
			double avgOfAll=(double)avg/50;
			System.out.println("The Average Amount of Steps for all lengths was "+avgOfAll+ " steps");
}
}
