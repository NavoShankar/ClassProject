package TurtleGraphics;

import java.util.Random;

public class BridgeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		KeyboardReader reader = new KeyboardReader();
		BridgeSecond object = new BridgeSecond();
		System.out.println("Length:");
		int length = reader.readInt();
		object.Output(length);
		
		}

}
