package TurtleGraphics.graphics;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Sprite {
	public int width, height;
	public int[] pixels;
	
	public static Sprite[] bg = createSprites("/blue.jpg");
	
	
	public Sprite(int width, int height, int color) {
		this.width = width;
		this.height = height;
		this.pixels = new int[width * height];
		
		for(int i = 0; i < pixels.length; i++) {
			pixels[i] = color;
		}
	}


	public Sprite(int[] pp) {
		this.width = 100;
		this.height = 100;
		this.pixels = new int[width * height];
		
		for(int y = 0; y < height; y++) {
			for(int x = 0; x < width; x++) {
				pixels[x + y * width] = pp[x + y * width];
			}
		}
	}


	private static Sprite[] createSprites(String path) {
		BufferedImage image;
		try {
			image = ImageIO.read(Sprite.class.getResource(path));
			//Image img = new ImageIcon(Sprite.getClass().getResource("/MyImage.gif")).getImage();
			int w = image.getWidth();
			int h = image.getHeight();
			int[] p = image.getRGB(0, 0, w, h, null, 0, w);
			Sprite[] sprites = new Sprite[16];
			
			for(int y = 0; y < 4; y++) {
				for(int x = 0; x < 4; x++) {
					int[] pp = new int[100 * 100];
					for(int yy = 0; yy < 100; yy++) {
						for(int xx = 0; xx < 100; xx++) {
							pp[xx + yy * 100] = p[(x * 100 + xx) + (y * 100 + yy) * w];
						}
					}
					sprites[x + y * 4] = new Sprite(pp);
				}
			}
			return sprites;			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return null;
	}
}
