package TurtleGraphics;

public class fhfg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		KeyboardReader reader = new KeyboardReader();
		System.out.println("j");
		int i = reader.readInt();
		System.out.println(i);
	}

}
