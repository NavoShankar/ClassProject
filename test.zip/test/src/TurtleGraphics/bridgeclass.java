package TurtleGraphics;

import java.util.Random;

public class bridgeclass {
	
	public void Method(int step) {
		Random generator = new Random();
	    step = generator.nextInt(2);
		
	}

}
