package TurtleGraphics;

import java.util.Random;

public class bridgeprogram {

	public static void main(String[] args) {
		 	int step = 0;
		 	int counter = 0;
		 	bridgeclass object = new bridgeclass();
			object.Method(step);
		    int position; //location of man on bridge
		    /*for(int i = 0; i < 50; i++)
		    {*/
		       position = 0;
		       while(true)
		       {
		          if (step == 0) {
		           position--;
		          } else {
		           position++;
		          }
		          
		       
		          if(step == 1) {
		            	  System.out.println("|--*--|");
		            	  
		        	  
		          }
		          
		          else if(step == 2) {
		        	  
		        	  System.out.println("|-*---|");
		          }
		          else if(step == 3) {
		        	  
		        	  System.out.println("|*----|");
		        	  break;
		          }
		          
		          
		          

		  

		    }
	}
}


		

            
        

