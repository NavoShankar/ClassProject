package TurtleGraphics.game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.util.Random;

import TurtleGraphics.Puzzle;
import TurtleGraphics.gameobject.Rect;
import TurtleGraphics.graphics.Renderer;
import TurtleGraphics.graphics.Sprite;
import TurtleGraphics.input.Mouse;

public class Game {


public static Rect[] rects = {
	new Rect(0, 0, Sprite.bg[0]),
	new Rect(100, 0, Sprite.bg[1]),
	new Rect(200, 0, Sprite.bg[2]),
	new Rect(300, 0, Sprite.bg[3]),
	new Rect(0, 100, Sprite.bg[4]),
	new Rect(100, 100, Sprite.bg[5]),
	new Rect(200, 100, Sprite.bg[6]),
	new Rect(300, 100, Sprite.bg[7]),
	new Rect(0, 200, Sprite.bg[8]),
	new Rect(100, 200, Sprite.bg[9]),
	new Rect(200, 200, Sprite.bg[10]),
	new Rect(300, 200, Sprite.bg[11]),
	new Rect(0, 300, Sprite.bg[12]),
	new Rect(100, 300, Sprite.bg[13]),
	new Rect(200, 300, Sprite.bg[14])
};

	public Random rand = new Random();
	
	public Game() {
		init();
	}
	
	public void init() {
		shuffle();
	}
	
	
	private void shuffle() {
		//swtiches indexes of array
		for(int i = 0; i < rects.length; i++) {
			int swap = rand.nextInt(rects.length - 1);
			int x = (int) rects[swap].x;
			int y = (int) rects[swap].y;
			rects[swap].x = rects[i].x;
			rects[swap].y = rects[i].y;
			rects[i].x = x;
			rects[i].y = y;
		}
		if(!solvable()) {
			shuffle();
		}
	}

	private boolean solvable() {
		//sees if the random shuffle is solvable or not by getting the x and y values and length
		int[] nums = new int[15];
		int total = 0;
		for(int i = 0; i < rects.length; i++) {
			nums[(int) (rects[i].x / 100 + rects[i].y / 100 * 4)] = i + 1;
		}
		for(int i = 0; i < nums.length; i++) {
			for(int j= i; j < nums.length; j++) {
				if(nums[i] > nums[j]) {
					total++;
				}
			}
		}
		System.out.println("Total is: " + total);
		if(total % 2 == 0) {
			return true;
		}else {
			return false;			
		}		
	}

	public void update() {
		if(Mouse.buttonUp(MouseEvent.BUTTON3)) {
			init();
		}
		for(int i = 0; i < rects.length; i++) {
			rects[i].update();
		}
	}
	
	public void render() {
		Renderer.renderBackground();

		for(int i = 0; i < rects.length; i++) {
			rects[i].render();
		}		
		
		for(int i = 0; i < Puzzle.pixels.length; i++) {
			Puzzle.pixels[i] = Renderer.pixels[i];
		}
	}

	public void renderText(Graphics2D g) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setFont(new Font("Impact", 0, 100));
		g.setColor(Color.orange);
		
		for(int i = 0; i < rects.length; i++) {
			String s = "" + (i + 1);
			int sw = g.getFontMetrics().stringWidth(s) / 2;
			g.drawString(s, (int) (rects[i].x + rects[i].width / 2) * Puzzle.scale - sw, (int) (rects[i].y + rects[i].height / 2) * Puzzle.scale + 38);
		}
		
	}
	
}
