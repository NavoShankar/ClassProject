package TurtleGraphics;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JFrame;

import TurtleGraphics.game.Game;
import TurtleGraphics.input.Mouse;

public class Puzzle extends Canvas implements Runnable {

	public static int WIDTH = 400, HEIGHT = 400;
	public static float scale = 2f;
	public JFrame frame;
	public Game game;
	public Thread thread;
	public boolean running = false;
	public Mouse mouse;
	
	public static BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
	public static int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
	
	public Puzzle() {
		//creates everything and intizalizes
		setPreferredSize(new Dimension((int) (WIDTH * scale), (int) (HEIGHT * scale)));
		game = new Game();
		frame = new JFrame();
		mouse = new Mouse();
		addMouseListener(mouse);
		addMouseMotionListener(mouse);
	}
	
	public void start() {
		//starts program
		running = true;
		thread = new Thread(this, "loop");
		thread.start();
	}
	
	public void stop() {
		//will keep going until until there is an error or player closes tab
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		//while running, game updates
		while(running) {
			update();
			render();
		}
		stop();
	}
	
	public void update() {
		game.update();
		mouse.update();
	}

	public void render() {
		BufferStrategy bs = getBufferStrategy();
		if(bs == null) {
			createBufferStrategy(3);
			return;
		}
	//////////////////////////////////////////////	
		game.render();
		
		Graphics2D g = (Graphics2D) bs.getDrawGraphics();
		g.drawImage(image, 0, 0, (int) (WIDTH * scale), (int) (HEIGHT * scale), null);
		game.renderText(g);
		g.dispose();
		bs.show();
	}	
	
	public static void main(String[] args) {
		//main, creates window
		Puzzle p = new Puzzle();
		p.frame.setResizable(false);
		p.frame.setTitle("15");
		p.frame.add(p);
		p.frame.pack();
		p.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		p.frame.setVisible(true);
		p.frame.setLocationRelativeTo(null);
		p.frame.setAlwaysOnTop(true);
		p.start();
	}
	

}


